# Nimbus Skin for Kodi Omega

  ![Viewtypes](resources/images/flix.jpg)
  
  ![Viewtypes](resources/images/flix1.jpg)


## INFO

- This is currently under development and is only available for Kodi Omega.
- I will not be accepting **ANY** feature requests for this skin. It comes as is.
